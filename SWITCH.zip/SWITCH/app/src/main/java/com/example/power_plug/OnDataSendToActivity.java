package com.example.power_plug;
/**
 * Created by dzulkiflee on 3/19/2017 AD.
 */

public interface OnDataSendToActivity {
    public void sendData(String str);
}
